#!/bin/sh

g++ src/*.cpp -o firewall
